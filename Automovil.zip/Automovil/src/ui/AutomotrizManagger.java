package ui;

import java.util.Scanner;

import model.AutomovilController;
import model.Vehicule;
//we need to create a program to manage the vehicles for sale of an automotive dealership.these vehicles are divided into different subclasses such as cars or motorcycles which have their own characteristics,this program should allow to create new or used vehicles,assign their prices depending on their characteristics,and create a replica of the parking lot virtually to organize the vehicles of the dealership,depending on the characteristics of the same,making it possible to vary their position.//
public class AutomotrizManagger {

	public static Scanner reader;

	public static AutomovilController AutomovilController;

	public static void main(String[] args) {
		init();
		showMainMenu();
	}

	private static void init() {

		reader = new Scanner(System.in);
		AutomovilController = new AutomovilController();
	}

	private static void showMainMenu() {
		 boolean flag=true;
		System.out.println("welcome to automitriz concessionaire 1.0");
		 while(flag==true){

		System.out.println("menu:");
		System.out.println(
				"1.register a vehicule\n2.register documentacion\n3.show the vehicules selling price\n4. generate the reports for all the vehicules\n5.show a vehicules document status\n6.show the garage�s map\n7.generate the parking garage report\n0.Exit");
		System.out.println("0. exit");

		int mainOption = reader.nextInt();

		switch (mainOption) {

		case 1:
			registerVehicule();
			break;
		case 2:
			reigisterDocuments();
			break;
		case 3:
			
			break;
		case 4:
			System.out.println(AutomovilController.showWVehiculesList());
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;

		case 0:
			System.out.println("thaks for using concessionary 1.0 see you later");
			flag=true;
		default:
			System.out.println("you choose a invalid comand please choose again. https://youtu.be/dQw4w9WgXcQ");

		}
		 }

	}

	private static void registerVehicule() {

		System.out.println("type the vehicules base price");
		
		double basePrice=reader.nextDouble();

		System.out.println("enter the vehicules actual price");
		
		double actualPrice=reader.nextDouble();

		System.out.println("type the new vehicule State \n1.new\n2.used");
		int type=reader.nextInt();
		
		System.out.println("type the number of kilometers who have the vehicule");
		double numberKm=reader.nextDouble();
		
		System.out.println("type the brand of the vehicule");
		String vehiculeBrand=reader.nextLine();
		vehiculeBrand=reader.nextLine();
		
		System.out.println("enter the vehicule model");
		int vehiculeModel=reader.nextInt();
		
		System.out.println("enter the plate of the vehicule");
		String vehiculePlate=reader.nextLine();
		vehiculePlate=reader.nextLine();
		
		System.out.println("type the vehicicule cilinder");
		int vehiculeCilinder=reader.nextInt();

		System.out.println("enter the type of the type of the new vehicule\n1.car\n2.motorcicle");
		int vehiculeType = reader.nextInt();
		switch (vehiculeType) {

		case 1:

			System.out.println("enter the new car type \n1.sedan\n2.pickup truck");
			int typeCar=reader.nextInt();

			System.out.println("enter the number of doors for the vehicule");
			int doorsNumner=reader.nextInt();

			System.out.println("the car have tinted windows?\n1.yes\n2.no");
			int tintedWindows=reader.nextInt();

			System.out.println("type the subtype of the car\n1.Electric car\n2.Gasoline car\n3.Hybrid car");
			int carSubtype = reader.nextInt();

			switch (carSubtype) {

			case 1:
				System.out.println("type the duracion of the battery");
				int batteryDuration=reader.nextInt();

				System.out.println("type the type of charger \n1.faster\n2.normal");
				int chargerType=reader.nextInt();
				break;
			case 2:
				System.out.println("type the gasoline type for the car\n1.regular\n2.diesel\n3.extra");
				int gasolineType=reader.nextInt();
				System.out.println("type the gasoline car tank capacity");
				int tankCapacity=reader.nextInt();
				break;
			case 3:

				System.out.println("type the duracion of the battery");
				int batteryDuration1=reader.nextInt();

				System.out.println("type the type of charger \n1.faster\n2.normal");
				
				int chargerType1=reader.nextInt();
				System.out.println("type the gasoline type for the car\n1.regular\n2.diesel\n3.extra");
				int gasolineType1=reader.nextInt();
				System.out.println("type the gasoline car tank capacity");
				int tankCapacity1=reader.nextInt();
				break;

			}

			break;

		case 2:
			
			System.out.println("enter the type of motorcycle \n1.STANDARD\n2.SPORT\n3.SPORT\n4.CROSS");
			
			int bikeType=reader.nextInt();
			
			System.out.println("enter the tank capacity");
			
			int motorcycleTankCapacity=reader.nextInt();
			break;

		}
		
		if (AutomovilController.registerVehicule(basePrice, actualPrice,type,vehiculeBrand,numberKm,vehiculeModel,vehiculePlate,vehiculeCilinder,typeCar)) {

			System.out.println("Vehicule registered succesfully");
			
			
			
			

		} else {

			System.out.println("Error, Document couldn't be registered");

		}
	}
		
	

	private static void reigisterDocuments() {
		
		System.out.println("These are the Wetlands currently registered:" + AutomovilController.showVehiculesId());

		System.out.println("enter the proce of the documents");
		double price = reader.nextDouble();

		System.out.println("enter the date of the document");
		String date = reader.nextLine();
		date = reader.nextLine();

		if (AutomovilController.registerDocument(price, date)) {

			System.out.println("Document registered succesfully");

		} else {

			System.out.println("Error, Document couldn't be registered");

		}
	}

}
