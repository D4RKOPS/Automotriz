package model;

public enum CarType {
	
 SEDAN,TRUCK
}
