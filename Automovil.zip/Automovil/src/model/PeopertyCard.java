package model;

public class PeopertyCard extends Documents {

	private int[][] propertyCardImage;

	public PeopertyCard(double price, String date) {
		super(price, date);

	}

	public int[][] getPropertyCardImage() {
		return propertyCardImage;
	}

	public void setPropertyCardImage(int[][] propertyCardImage) {
		this.propertyCardImage = propertyCardImage;
	}

	private String generatePropertyCardImage() {

		String code = "";
		boolean fin = false;
		for (int i = 0; i < 4; i++) {
			fin = false;
			System.out.println(i);
			for (int a = 3; a > -1 && !fin; a--) {
				a = a - i;
				System.out.println(a);
				System.out.println(propertyCardImage[i][a]);
				code += propertyCardImage[i][a] + "";
				fin = true;
				System.out.println(code);
				return code;

			}
		}

		return code;

	}

	private String printSoatImage(int[][] propertyCardImage) {
		String print = "";
		for (int i = 0; i < propertyCardImage.length; i++) {
			for (int j = 0; j < propertyCardImage[0].length; j++) {
				print += propertyCardImage[i][j] + " ";
			}
			print += "\n";
		}
		return print;
	}

}