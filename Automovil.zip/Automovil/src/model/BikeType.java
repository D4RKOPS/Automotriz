package model;

public enum BikeType {

	STANDARD, SPORT, SCOOTER,CROSS
	
	
	
}
