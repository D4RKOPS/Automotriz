package model;

public class GasolineCar extends Vehicule implements GasolineConsume {

	private int tankCapacity;

	private GasolineType gasolineType;

	public GasolineCar(double basePrice, double actualPrice, int type, String vehiculeBrand, double numberKm,
			int vehiculeModel, String vehiculePlate, int vehiculeCilinder, int tankCapacity, int gasolineType) {
		super(basePrice, actualPrice, type, vehiculeBrand, numberKm, vehiculeModel, vehiculePlate, vehiculeCilinder);
		// TODO Auto-generated constructor stub
		this.tankCapacity = tankCapacity;
		switch (gasolineType) {
		case 1:
			this.gasolineType = GasolineType.CURRENT;
			break;
		case 2:
			this.gasolineType = GasolineType.DIESEL;
			break;
		case 3:
			this.gasolineType = GasolineType.EXTRA;
			break;

		}

	}

	public int getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(int tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	public GasolineType getGasolineType() {
		return gasolineType;
	}

	public void setGasolinetype(GasolineType gasolineType) {
		this.gasolineType = gasolineType;
	}

	@Override
	public double calculateGasolineConsume() {
		double gasolineConsume = 0;

		gasolineConsume += tankCapacity * (getVehiculeCilinder() / 150);

		return gasolineConsume;
	}

	@Override
	public String toString() {
		return "GasolineCar [tankCapacity=" + tankCapacity + ", gasolineType=" + gasolineType + "]";
	}

}