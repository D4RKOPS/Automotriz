package model;

public enum VehiculeType {

	NEW,USED
}
