package model;

public enum GasolineType {

	EXTRA,CURRENT,DIESEL
}