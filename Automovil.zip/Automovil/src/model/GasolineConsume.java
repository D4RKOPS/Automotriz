package model;

public interface GasolineConsume {

	public double calculateGasolineConsume();

}
