package model;

public enum SubTypeCar {

	ELECTRIC,GASOLINE,HIBRID
}
