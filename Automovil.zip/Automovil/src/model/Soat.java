package model;

import java.util.Arrays;
import java.util.Random;

public class Soat extends Documents{

	private int[][] soatImage;
	public Soat(double price, String date) {
		super(price, date);
		
	}
	public int[][] getSoatImage() {
		return soatImage;
	}
	public void setSoatImage(int[][] soatImage) {
		this.soatImage = soatImage;
	}
	
	public int[][] GenerateSoatMatrix(){
		
		Random rd = new Random();
		
		int[][] soatMatrix = new int[4][4];
		for (int i = 0; i < soatMatrix.length; i++) {
			for (int j = 0; j < soatMatrix[0].length; j++) {
				soatMatrix[i][j] = rd.nextInt(10);

			}
		}
		
		
		return soatMatrix;
		
		
	}
	
	private String generateSoatImage() {

		String code = "";
		    boolean fin =false;
		    for(int i=0;i<4; i++) {
		        fin=false;
		        System.out.println(i);
		        for(int a=3;a>-1 && !fin;a--){
		             a=a-i;
		             System.out.println(a);
		             System.out.println(soatImage[i][a]);
		             code+=soatImage[i][a]+"";
		              fin=true;
		     System.out.println(code);
		     return code;

					}
				}
			
	

		
		return code;

	}
	private String printSoatImage(int[][] soatImage) {
		String print = "";
		for (int i = 0; i < soatImage.length; i++) {
			for (int j = 0; j < soatImage[0].length; j++) {
				print += soatImage[i][j] + " ";
			}
			print += "\n";
		}
		return print;
	}
	
	@Override
	public String toString() {
		return "Soat [soatImage=" + Arrays.toString(soatImage) + "]";
	}
	
}