package model;

public class Motorcycle extends Vehicule implements GasolineConsume {

	private int motorcycleTankCapacity;
	
	private BikeType bikeType;

	public Motorcycle(double basePrice, double actualPrice, int type, String vehiculeBrand, double numberKm,
			int vehiculeModel, String vehiculePlate, int vehiculeCilinder, int motorcycleTankCapacity,int bikeType) {
		super(basePrice, actualPrice, type, vehiculeBrand, numberKm, vehiculeModel, vehiculePlate, vehiculeCilinder);

		this.motorcycleTankCapacity = motorcycleTankCapacity;
		
		switch(bikeType) {
		
		case 1:
			this.bikeType=BikeType.STANDARD;
			break;
			
		case 2:
			this.bikeType=BikeType.SPORT;
			break;
			
		case 3:
			this.bikeType=BikeType.SCOOTER;
			break;
		case 4:
			this.bikeType=BikeType.CROSS;
			break;
		
		
		
		}
	}

	public int getMotorcycleTankCapacity() {
		return motorcycleTankCapacity;
	}

	public void setMotorcycleTankCapacity(int motorcycleTankCapacity) {
		this.motorcycleTankCapacity = motorcycleTankCapacity;
	}

	@Override
	public double calculateGasolineConsume() {
		double gasolineConsume = 0;

		gasolineConsume += motorcycleTankCapacity * (getVehiculeCilinder() / 75);

		return gasolineConsume;

	}

	public BikeType getBikeType() {
		return bikeType;
	}

	public void setBikeType(BikeType bikeType) {
		this.bikeType = bikeType;
	}

}