package model;

public class Vehicule {
	
	
	private String vehiculePlate;
	
	private String vehiculeBrand;
	
	private int vehiculeModel;
	
	private int vehiculeCilinder;
	
	private double basePrice;
	
	private double numberKm;

	private double actualPrice;

	private VehiculeType type;

	public Vehicule(double basePrice, double actualPrice, int type,String vehiculeBrand,double numberKm,int vehiculeModel,String vehiculePlate,int vehiculeCilinder) {
		
		this.vehiculeCilinder=vehiculeCilinder;
		this.vehiculePlate=vehiculePlate;
		this.numberKm=numberKm;
		this.basePrice = basePrice;
		this.actualPrice = actualPrice;
		this.vehiculeModel=vehiculeModel;
		this.setVehiculeBrand(vehiculeBrand);
		switch (type) {
		case 1:
			this.type = VehiculeType.NEW;
			break;

		case 2:
			this.type = VehiculeType.USED;
			break;

		}

	}

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public double getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(double actualPrice) {
		this.actualPrice = actualPrice;
	}

	public VehiculeType getType() {
		return type;
	}

	public void setType(VehiculeType type) {
		this.type = type;
	}

	public String getVehiculeBrand() {
		return vehiculeBrand;
	}

	public void setVehiculeBrand(String vehiculeBrand) {
		this.vehiculeBrand = vehiculeBrand;
	}

	

	public double getNumberKm() {
		return numberKm;
	}

	public void setNumberKm(double numberKm) {
		this.numberKm = numberKm;
	}

	public int getVehiculeModel() {
		return vehiculeModel;
	}

	public void setVehiculeModel(int vehiculeModel) {
		this.vehiculeModel = vehiculeModel;
	}

	public String getVehiculePlate() {
		return vehiculePlate;
	}

	public void setVehiculePlate(String vehiculePlate) {
		this.vehiculePlate = vehiculePlate;
	}

	public int getVehiculeCilinder() {
		return vehiculeCilinder;
	}

	public void setVehiculeCilinder(int vehiculeCilinder) {
		this.vehiculeCilinder = vehiculeCilinder;
	}
	

	@Override
	public String toString() {
		return "\n.Vehicule [vehiculePlate=" + vehiculePlate + ",\n. vehiculeBrand=" + vehiculeBrand + ",\n vehiculeModel="
				+ vehiculeModel + ", \n vehiculeCilinder=" + vehiculeCilinder + ",\n basePrice=" + basePrice + ",\n numberKm="
				+ numberKm + ",\n actualPrice=" + actualPrice + ", \n type=" + type +"]";
	}
}
