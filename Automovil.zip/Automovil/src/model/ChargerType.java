package model;

public enum ChargerType {

	FASTER,NORMAL
}
