package model;

public class ElectricCar extends Vehicule implements BatteryConsume {

	private int batteryDuration;

	private ChargerType chargerType;

	public ElectricCar(double basePrice, double actualPrice, int type, String vehiculeBrand, double numberKm,
			int vehiculeModel, String vehiculePlate, int vehiculeCilinder, int chargerType, int batteryDuration) {
		super(basePrice, actualPrice, type, vehiculeBrand, numberKm, vehiculeModel, vehiculePlate, vehiculeCilinder);

		this.batteryDuration = batteryDuration;
		switch (chargerType) {
		case 1:
			this.chargerType = ChargerType.FASTER;
			break;
		case 2:
			this.chargerType = ChargerType.NORMAL;
			break;
		}

	}

	public int getBatteryDuration() {
		return batteryDuration;
	}

	public void setBatteryDuration(int batteryDuration) {
		this.batteryDuration = batteryDuration;
	}

	public ChargerType getChargerType() {
		return chargerType;
	}

	public void setChargerType(ChargerType chargerType) {
		this.chargerType = chargerType;
	}

	@Override
	public double calculateBatteryConsume() {
		int batteryConsume = 0;
		
		switch(chargerType) {
		case 1:
		batteryConsume += (batteryDuration + 13) * (getVehiculeCilinder() / 100);
		break;
		case 2:
			batteryConsume += (batteryDuration + 18) * (getVehiculeCilinder() / 100);
			break;
		}
		
		return batteryConsume;
	}

	@Override
	public String toString() {
		return "ElectricCar [batteryDuration=" + batteryDuration + ", chargerType=" + chargerType + "]";
	}

}