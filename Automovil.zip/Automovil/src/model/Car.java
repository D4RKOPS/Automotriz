package model;

public class Car{
	
	private int doorsNumber;
	
	private int tintedWindows;
	
	private CarType typeCar;
	
	private SubTypeCar subTypeCar;
	
	
	
	public Car(int doorsNumber,int tintedWindows,int typeCar,int subTypeCar) {
		
		this.doorsNumber=doorsNumber;
		
		this.tintedWindows=tintedWindows;
		
		switch(typeCar) {
		case 1:
			this.setTypeCar(CarType.SEDAN);
			break;
		case 2:
			this.setTypeCar(CarType.TRUCK);
			break;
			
		}
		
		switch(subTypeCar) {
		
		case 1:
			this.subTypeCar=SubTypeCar.ELECTRIC;
			
			break;
		case 2:
			this.subTypeCar=SubTypeCar.GASOLINE;
			break;
		case 3:
			this.subTypeCar=SubTypeCar.HIBRID;
			break;
		
		
		
		}
		
		
	}
	
	

	public int getDoorsNumber() {
		return doorsNumber;
	}

	public void setDoorsNumber(int doorsNumber) {
		this.doorsNumber = doorsNumber;
	}

	public int getTintedWindows() {
		return tintedWindows;
	}

	public void setTintedWindows(int tintedWindows) {
		this.tintedWindows = tintedWindows;
	}



	public CarType getTypeCar() {
		return typeCar;
	}



	public void setTypeCar(CarType typeCar) {
		this.typeCar = typeCar;
	}



	public SubTypeCar getSubTypeCar() {
		return subTypeCar;
	}



	public void setSubTypeCar(SubTypeCar subTypeCar) {
		this.subTypeCar = subTypeCar;
	}


	
	
	
}
