package model;

public interface BatteryConsume {

	public double calculateBatteryConsume();
}
