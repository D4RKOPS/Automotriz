package model;

public class HibridCar extends Vehicule implements GasolineConsume, BatteryConsume {

	private int tankCapacity1;

	private GasolineType gasolineType1;

	private ChargerType chargerType1;

	private int batteryDuration1;

	public HibridCar(double basePrice, double actualPrice, int type, String vehiculeBrand, double numberKm,
			int vehiculeModel, String vehiculePlate, int vehiculeCilinder, int tankCapacity1, int gasolineType1,
			int batteryDuration1, int chargerType1) {
		super(basePrice, actualPrice, type, vehiculeBrand, numberKm, vehiculeModel, vehiculePlate, vehiculeCilinder);
		// TODO Auto-generated constructor stub

		this.batteryDuration1 = batteryDuration1;
		this.tankCapacity1 = tankCapacity1;
		switch (gasolineType1) {
		case 1:
			this.setGasolineType1(GasolineType.CURRENT);
			break;
		case 2:
			this.setGasolineType1(GasolineType.DIESEL);
			break;
		case 3:
			this.setGasolineType1(GasolineType.EXTRA);
			break;

		}
		switch (chargerType1) {
		case 1:
			this.chargerType1 = ChargerType.FASTER;
			break;
		case 2:
			this.chargerType1 = ChargerType.NORMAL;
			break;
		}

	}

	

	@Override
	public String toString() {
		return "HibridCar [tankCapacity1=" + tankCapacity1 + ", gasolineType1=" + gasolineType1 + ", chargerType1="
				+ chargerType1 + ", batteryDuration1=" + batteryDuration1 + "gasoline consume"+"]";
	}



	@Override
	public double calculateGasolineConsume() {
		// TODO Auto-generated method stub
		double gasolineConsume = 0;

		gasolineConsume += tankCapacity1 * (getVehiculeCilinder() / 180);

		return gasolineConsume;

	}

	@Override
	public double calculateBatteryConsume() {
		int batteryConsume = 0;

		switch (chargerType1) {
		case 1:
			batteryConsume += batteryDuration1 * (getVehiculeCilinder() / 200);
			break;
		case 2:
			batteryConsume += (batteryDuration1 + 7) * (getVehiculeCilinder() / 200);
			break;
			return batteryConsume;
		}

	}



	public int getTankCapacity1() {
		return tankCapacity1;
	}



	public void setTankCapacity1(int tankCapacity1) {
		this.tankCapacity1 = tankCapacity1;
	}



	public GasolineType getGasolineType1() {
		return gasolineType1;
	}



	public void setGasolineType1(GasolineType gasolineType1) {
		this.gasolineType1 = gasolineType1;
	}



	public ChargerType getChargerType1() {
		return chargerType1;
	}



	public void setChargerType1(ChargerType chargerType1) {
		this.chargerType1 = chargerType1;
	}



	public int getBatteryDuration1() {
		return batteryDuration1;
	}



	public void setBatteryDuration1(int batteryDuration1) {
		this.batteryDuration1 = batteryDuration1;
	}

}