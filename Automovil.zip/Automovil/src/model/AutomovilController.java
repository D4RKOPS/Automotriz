package model;

import java.util.ArrayList;

public class AutomovilController{
	
	ArrayList<Vehicule> vehiculeParking;
	ArrayList<Documents> documents;
	
	
	
	public AutomovilController() {
		super();
		this.vehiculeParking=new ArrayList<Vehicule>();
		this.documents=new  ArrayList<Documents>();
		
		
		
	}
	
	//decription: this metod register the vehicules 
		//preondicion:the values who contains vehicue
		//postcondicion:the values gonna be registred and assigned to the arraylist
		
	
	public boolean registerVehicule(double basePrice, double actualPrice, int type,String vehiculeBrand,double numberKm,int vehiculeModel,String vehiculePlate,int vehiculeCilinder,int typeCar) {
		
		return vehiculeParking.add(new Vehicule(basePrice, actualPrice,type,vehiculeBrand,numberKm,vehiculeModel,vehiculePlate,vehiculeCilinder));
		
	}
	
	
	
public boolean registerDocument(double price,String date) {

		
		
		return documents.add(new Documents(price, date));

	}
	
public String showVehiculesId() {

	String msg = "";

	for (int i = 0; i < vehiculeParking.size(); i++) {
		

		if (vehiculeParking.get(i) != null) {

			msg += vehiculeParking.get(i).getVehiculeBrand()+"-"+vehiculeParking.get(i).getVehiculeModel();
		}
	}

	return msg;

}


public String showWVehiculesList() {

		String out = "";
for(int i=0;i<vehiculeParking.size();i++) {
	
	for(int j=0;j<vehiculeParking.size();j++) {
	
	
	out+=vehiculeParking.get(i).toString();
	
}}
		return out;
	}
	
}
